@echo off
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>&1
if errorlevel 1 (
 echo กรุณาติดตั้ง Node.js 24.17.0 ขึ้นไปก่อน: https://nodejs.org/en/download
 pause
 exit /b 1
)
if not exist .env (
 copy .env.example .env >nul
 echo สร้างไฟล์ .env แล้ว กรุณาใส่ DISCORD_TOKEN CLIENT_ID GUILD_ID
 notepad .env
)
call npm install
if errorlevel 1 (
 echo ติดตั้งไม่สำเร็จ ตรวจสอบอินเทอร์เน็ตและ Node.js
 pause
 exit /b 1
)
echo ติดตั้งสำเร็จ จากนั้นดับเบิลคลิก REGISTER_WINDOWS.bat และ RUN_WINDOWS.bat
pause
